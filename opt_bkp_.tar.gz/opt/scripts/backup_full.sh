#!/bin/bash
backup_dest="/backup_dir"

ayuda() {
  echo "Modo de uso: $0 [origen] [destino]"
  echo "Ejemplo: $0 /etc /backup_dir"
  exit 0
}

if [[ "$1" == "-h" ]]; then
  ayuda
fi

if [[ $# -ne 2 ]]; then
  echo "Error: Se requieren dos argumentos, origen y destino."
fi

ORIGEN=$1
DESTINO=$2

if [[ ! -d "$ORIGEN" ]]; then
  echo "Error: El directorio de origen no existe."
  exit 1
fi

NOMBRE_DIR=(basename "$ORIGEN")
FECHA=$(date +%Y%m%d)
BACKUP_NOMBRE="${DESTINO}/${NOMBRE_DIR}_bkp_${FECHA}.tar.gz"

tar -czf "$BACKUP_NOMBRE" -C "$ORIGEN" .

if [[ $? -eq 0 ]]; then
    echo "Respaldo completado con éxito: $BACKUP_NOMBRE"
else 
    echo "Error: Hubo un fallo en el proceso."
    exit 1
fi

